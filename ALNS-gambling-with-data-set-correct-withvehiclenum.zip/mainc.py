# 导入必要的模块和函数
from a_read_instance import read_solomon_instance
from b_CCMFEVRP_PRTW_instance import CustomEVRPInstance, Location
from c_constraints import Constraints

def run_constraints_check():
    # 读取Solomon实例数据
    file_path = "c101_21.txt"  # 请确保文件路径正确
    locations_data, vehicles_data = read_solomon_instance(file_path)

    # 创建Location对象列表，并创建CustomEVRPInstance对象
    locations = [Location(**loc) for loc in locations_data]
    instance = CustomEVRPInstance(locations, vehicles_data)

    # 创建Constraints对象
    constraints_checker = Constraints(instance)

    # 修改后的测试路径
    test_route = [0, 39, 70, 83, 34, 6, 3, 0]  # 重新排序后的路径

    # 运行约束检查并输出调试信息
    print("Checking node visit...")
    node_visit_passed = constraints_checker.check_node_visit(test_route)
    print(f"Node visit check passed: {node_visit_passed}\n")

    print("Checking load balance...")
    load_balance_passed = constraints_checker.check_load_balance(test_route, vehicle_type='electric')
    print(f"Load balance check passed: {load_balance_passed}\n")

    print("Checking time window...")
    time_window_passed = constraints_checker.check_time_window(test_route)
    print(f"Time window check passed: {time_window_passed}\n")

    print("Checking battery constraints...")
    battery_check_passed = constraints_checker.check_battery(test_route)
    print(f"Battery check passed: {battery_check_passed}\n")

    # 输出更多的详细信息进行调试
    print("Route details:")
    for i, node in enumerate(test_route):
        print(f"Node {i}: Index {node}, X: {instance.locations[node].x}, Y: {instance.locations[node].y}, "
              f"ReadyTime: {instance.locations[node].ready_time}, DueDate: {instance.locations[node].due_date}, "
              f"Demand: {instance.locations[node].demand}, Type: {instance.locations[node].type}")

# 调用运行函数
if __name__ == "__main__":
    run_constraints_check()

