import numpy as np

def calculate_scores(instance):
    """
    计算每个客户的评分，用于分配给电动车或燃油车。

    参数:
    instance (CustomEVRPInstance): 问题实例，包含客户位置、需求等数据。

    返回:
    tuple: 包含电动车评分、燃油车评分、最小需求、最大需求、lambda 参数、距离评分和需求评分的元组。
    """
    # 初始化两个集合 E 和 C
    E = []  # 电动车分配客户集合
    C = []  # 燃油车分配客户集合

    # 计算电动车和燃油车的初始距离
    d_E = np.linalg.norm(instance.customer_positions - instance.depot_position, axis=1)
    d_C = np.linalg.norm(instance.customer_positions - instance.depot_position, axis=1)

    # 计算电动车的评分
    d_E_min = np.min(d_E)
    d_E_max = np.max(d_E)
    if d_E_max != d_E_min:
        p_E = 11 - 1 + (d_E - d_E_min) / (d_E_max - d_E_min) * 9  # 归一化评分在 2 到 11 之间
    else:
        print("Warning: d_E_max is equal to d_E_min, cannot perform division.")
        p_E = np.full(d_E.shape, 11 - 1)  # 设置默认得分

    # 计算燃油车的评分
    d_C_min = np.min(d_C)
    d_C_max = np.max(d_C)
    q_min = np.min(instance.customer_demand)
    q_max = np.max(instance.customer_demand)

    lambda_param = 0.5  # 可调参数
    if d_C_max != d_C_min:
        pDist_C = 11 - 1 + (d_C - d_C_min) / (d_C_max - d_C_min) * 9  # 归一化评分在 2 到 11 之间
    else:
        print("Warning: d_C_max is equal to d_C_min, cannot perform division.")
        pDist_C = np.full(d_C.shape, 11 - 1)  # 设置默认得分

    if q_max != q_min:
        pQ = 11 - 1 + (instance.customer_demand - q_min) / (q_max - q_min) * 9  # 归一化评分在 2 到 11 之间
    else:
        pQ = np.full(instance.customer_demand.shape, 11 - 1)  # 设置默认得分

    p_C = lambda_param * pDist_C + (1 - lambda_param) * pQ  # 混合评分

    return p_E, p_C, q_min, q_max, lambda_param, pDist_C, pQ

def clustering(instance):
    """
    根据评分将客户分配给电动车或燃油车。

    参数:
    instance (CustomEVRPInstance): 问题实例，包含客户位置、需求等数据。

    返回:
    tuple: 包含分配给电动车的客户列表和分配给燃油车的客户列表的元组。
    """
    # 初始化
    p_E, p_C, q_min, q_max, lambda_param, pDist_C, pQ = calculate_scores(instance)
    E, C = [], []
    unassigned_customers = set(range(instance.n))  # 所有未分配的客户

    while unassigned_customers:
        i_E = max(unassigned_customers, key=lambda i: p_E[i])  # 选择评分最高的客户分配给电动车
        i_C = max(unassigned_customers, key=lambda i: p_C[i])  # 选择评分最高的客户分配给燃油车

        if i_E == i_C:
            E.append(i_E)
            unassigned_customers.remove(i_E)
        else:
            if p_E[i_E] > p_C[i_C]:
                E.append(i_E)
                unassigned_customers.remove(i_E)
            else:
                C.append(i_C)
                unassigned_customers.remove(i_C)

        # 重新计算未分配客户的评分
        remaining_customers = list(unassigned_customers)
        if remaining_customers:
            E_positions = instance.customer_positions[E]
            C_positions = instance.customer_positions[C]

            E_barycenter = np.mean(E_positions, axis=0) if E_positions.size else instance.depot_position
            C_barycenter = np.mean(C_positions, axis=0) if C_positions.size else instance.depot_position

            d_E = np.linalg.norm(instance.customer_positions[remaining_customers] - E_barycenter, axis=1)
            d_C = np.linalg.norm(instance.customer_positions[remaining_customers] - C_barycenter, axis=1)

            d_E_min = np.min(d_E)
            d_E_max = np.max(d_E)
            d_C_min = np.min(d_C)
            d_C_max = np.max(d_C)
            # 添加调试信息
            print(f"d_E: {d_E}, d_E_min: {d_E_min}, d_E_max: {d_E_max}")
            print(f"d_C: {d_C}, d_C_min: {d_C_min}, d_C_max: {d_C_max}")

            # 确保 d_E_max - d_E_min 和 d_C_max - d_C_min 不为零
            if d_E_max != d_E_min:
                p_E[remaining_customers] = 11 - 1 + (d_E - d_E_min) / (d_E_max - d_E_min) * 9  # 重新计算电动车评分
            else:
                print("Warning: d_E_max is equal to d_E_min, cannot perform division.")
                p_E[remaining_customers] = 11 - 1  # 设置默认得分

            if d_C_max != d_C_min:
                pDist_C[remaining_customers] = 11 - 1 + (d_C - d_C_min) / (d_C_max - d_C_min) * 9  # 重新计算燃油车距离评分
            else:
                print("Warning: d_C_max is equal to d_C_min, cannot perform division.")
                pDist_C[remaining_customers] = 11 - 1  # 设置默认得分

            if q_max != q_min:
                pQ[remaining_customers] = 11 - 1 + (instance.customer_demand[remaining_customers] - q_min) / (q_max - q_min) * 9  # 重新计算需求评分
            else:
                pQ[remaining_customers] = 11 - 1  # 设置默认得分

            p_C[remaining_customers] = lambda_param * pDist_C[remaining_customers] + (1 - lambda_param) * pQ[remaining_customers]  # 重新计算燃油车混合评分

    return E, C  # 返回分配结果
