# Examples

This directory stores a number of example notebooks that are rendered in the
online documentation. Most of these notebooks depend on data files available 
in `data/`. New notebooks should also add their dependent data files to the
`data/` directory.
