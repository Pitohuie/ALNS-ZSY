from .MaxIterations import MaxIterations
from .MaxRuntime import MaxRuntime
from .NoImprovement import NoImprovement
from .StoppingCriterion import StoppingCriterion
